#!/bin/bash

zip -r "bot_forms.zip" * -x "bot_forms.zip"